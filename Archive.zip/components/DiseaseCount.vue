<template>
	<div>
		{{ disease }} : {{ cnt }}
	</div>
</template>

<script>
export default {
  props: ['disease', 'cnt']
}
</script>

<style>
</style>
